Telegram chat-bot <a href = "https://t.me/muslibbot">🎧Mus Lib</a>
===============================================

Telegram chat-bot
for downloading music from https://vk.com

1. Searches and downloads by title or author🎶
2. Has its own custom playlist system📔
3. Soon fingerfind-song technology in bot🔊

===============================================
