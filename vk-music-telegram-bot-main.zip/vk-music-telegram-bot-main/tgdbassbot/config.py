API_TOKEN = "TOKEN"

commands = ['/start', '/song', '/artist', '/setlang',
            '/settings', '/my', '/users', '/newpost']
